#ifndef ADMIN_FUNCTIONS_H
#define ADMIN_FUNCTIONS_H

#include <string> 




namespace AdminFunctions {
    void displayAdminHeader();
    void viewListings();
    void addListing();
    void deleteListing();
    void modifyListing(); 
    void viewPurchaseHistory();
    void runAdminInteractiveMode();

    
    void handleAdminCli(int argc, char *argv[]);
}

#endif 