#ifndef USER_FUNCTIONS_H
#define USER_FUNCTIONS_H

#include <string> 

namespace UserFunctions {
    void displayUserHeader();
    void viewAvailableListings();
    void addListingToFavourites();
    void viewFavouritesList();
    void buyListing();
    void viewUserPurchaseHistory();
    void runUserInteractiveMode();

    
    void handleUserCli(int argc, char *argv[]);
}

#endif 