#include "admin_functions.h"
#include "file_operations.h" 
#include <iostream>

int main(int argc, char *argv[]) {
    

    if (argc > 1) {
        AdminFunctions::handleAdminCli(argc, argv);
    } else {
        
        
        
        AdminFunctions::runAdminInteractiveMode();
    }

    return 0;
}