#ifndef FILE_OPERATIONS_H
#define FILE_OPERATIONS_H

#include <string>
#include <vector>
#include "listing.h" 

namespace FileOps {
    
    const std::string LISTINGS_FILE = "listings.txt";
    const std::string FAVOURITES_FILE = "fav.txt";
    const std::string HISTORY_FILE = "history.txt";
    const std::string TEMP_FILE = "temp_listings_file.txt"; 

    
    std::vector<Listing> readListingsFromFile(const std::string& filename);

    
    bool writeListingsToFile(const std::string& filename, const std::vector<Listing>& listings);

    
    void displayParsedListings(const std::vector<Listing>& listings, const std::string& header_color, const std::string& header_text);

    
    bool displayRawFileContents(const std::string& filename, const std::string& header_color, const std::string& header_text);

    
    bool appendListingStringToFile(const std::string& filename, const std::string& listing_string);

    
    std::string findListingStringByOrderNum(const std::string& filename, int order_num);

    
    bool removeListingByOrderNum(const std::string& filename, int order_num_to_remove);

    
    int getNextAvailableOrderNumber(const std::string& filename);

    
    bool moveListing(const std::string& source_filename, const std::string& dest_filename, int order_num);

    
    void clearCinBuffer();
}

#endif 