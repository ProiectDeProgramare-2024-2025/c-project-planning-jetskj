#ifndef LISTING_H
#define LISTING_H

#include <string>
#include <vector> 

class Listing {
public:
    int orderNumber;
    std::string type;
    std::string price;
    std::string size;
    std::string rooms;
    std::string bathrooms;
    std::string parking;
    std::string originalLine; 

private:
    bool isValid_; 

public:
    Listing(); 
    explicit Listing(const std::string& line); 

    std::string toString() const; 
    bool isValid() const; 

    static int extractOrderNumber(const std::string& line);
    static std::string trim(const std::string& str);
};

#endif 