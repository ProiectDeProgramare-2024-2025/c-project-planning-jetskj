#include "admin_functions.h"
#include "file_operations.h"
#include "ansi_colors.h"
#include "listing.h" 
#include <iostream>
#include <string>
#include <vector>
#include <limits> 
#include <sstream> 

namespace AdminFunctions {

    void displayAdminHeader() {
        std::cout << BOLD << MAGENTA << "------ ADMIN MENU ------" << RESET << std::endl;
        std::cout << "1 - View All Listings" << std::endl;
        std::cout << "2 - Add New Listing" << std::endl;
        std::cout << "3 - Delete Listing" << std::endl;
        std::cout << "4 - Modify Listing (Basic)" << std::endl;
        std::cout << "5 - View Purchase History" << std::endl;
        std::cout << "0 - Exit Admin Panel" << std::endl;
        std::cout << MAGENTA << "------------------------" << RESET << std::endl;
    }

    void viewListings() {
        FileOps::displayRawFileContents(FileOps::LISTINGS_FILE, CYAN, "------- Available Listings -------");
    }

    void addListing() {
        std::string type_str, price_str, size_str, rooms_str, bathrooms_str, parking_str;
        std::string temp_input;

        std::cout << BOLD << GREEN << "------- Add New Listing -------" << RESET << std::endl;
        
        
        

        std::cout << "Enter listing type (e.g., House, Apartment): ";
        std::getline(std::cin, type_str);

        std::cout << "Enter price (e.g., 150000$): ";
        std::getline(std::cin, price_str);

        std::cout << "Enter size (e.g., 100sq): ";
        std::getline(std::cin, size_str);

        std::cout << "Enter number of rooms (e.g., 3 rooms): ";
        std::getline(std::cin, rooms_str);

        std::cout << "Enter number of bathrooms (e.g., 2 bathrooms): ";
        std::getline(std::cin, bathrooms_str);

        std::cout << "Enter parking details (e.g., parking space included, no parking space): ";
        std::getline(std::cin, parking_str);

        int next_order_num = FileOps::getNextAvailableOrderNumber(FileOps::LISTINGS_FILE);

        std::stringstream new_listing_ss;
        new_listing_ss << next_order_num << ". "
                       << Listing::trim(type_str) << ", "
                       << Listing::trim(price_str) << ", "
                       << Listing::trim(size_str) << ", "
                       << Listing::trim(rooms_str) << ", "
                       << Listing::trim(bathrooms_str) << ", "
                       << Listing::trim(parking_str);
        
        
        std::string new_listing_line = new_listing_ss.str() + "\n";


        if (FileOps::appendListingStringToFile(FileOps::LISTINGS_FILE, new_listing_line)) {
            std::cout << GREEN << "Listing added successfully with order number " << next_order_num << "." << RESET << std::endl;
        } else {
            std::cout << RED << "Failed to add listing." << RESET << std::endl;
        }
    }

    void deleteListing() {
        int order_num;
        std::cout << BOLD << YELLOW << "------- Delete Listing -------" << RESET << std::endl;
        std::cout << "Current Listings:" << std::endl;
        FileOps::displayRawFileContents(FileOps::LISTINGS_FILE, "", ""); 
        
        std::cout << "Enter order number of the listing to delete: ";
        std::cin >> order_num;
        if (std::cin.fail()) {
            std::cout << RED << "Invalid input. Please enter a number." << RESET << std::endl;
            FileOps::clearCinBuffer();
            return;
        }
        FileOps::clearCinBuffer(); 

        if (FileOps::removeListingByOrderNum(FileOps::LISTINGS_FILE, order_num)) {
            std::cout << GREEN << "Listing " << order_num << " deleted successfully." << RESET << std::endl;
        } else {
            std::cout << YELLOW << "Failed to delete listing " << order_num << " (may not exist or error occurred)." << RESET << std::endl;
        }
    }
    
    void modifyListing() {
        int order_num;
        std::cout << BOLD << YELLOW << "------- Modify Listing (Basic) -------" << RESET << std::endl;
        std::cout << "Current Listings:" << std::endl;
        FileOps::displayRawFileContents(FileOps::LISTINGS_FILE, "", "");

        std::cout << "Enter order number of the listing to modify: ";
        std::cin >> order_num;
        if (std::cin.fail()) {
            std::cout << RED << "Invalid input for order number." << RESET << std::endl;
            FileOps::clearCinBuffer();
            return;
        }
        FileOps::clearCinBuffer(); 

        std::string found_listing_str = FileOps::findListingStringByOrderNum(FileOps::LISTINGS_FILE, order_num);
        if (found_listing_str.empty()) {
            std::cout << YELLOW << "Listing " << order_num << " not found." << RESET << std::endl;
            return;
        }

        Listing old_listing(found_listing_str); 
        if (!old_listing.isValid()) {
            std::cout << RED << "Error parsing existing listing data for listing " << order_num << "." << RESET << std::endl;
            return;
        }

        std::cout << "Found Listing: " << old_listing.toString();
        std::cout << "Which field to modify? (type/price/size/rooms/bathrooms/parking): ";
        std::string field_to_modify;
        std::getline(std::cin, field_to_modify);
        field_to_modify = Listing::trim(field_to_modify);

        std::string new_value;
        std::cout << "Enter new value for " << field_to_modify << ": ";
        std::getline(std::cin, new_value);
        new_value = Listing::trim(new_value);

        Listing modified_listing = old_listing; 
        bool changed = false;
        if (field_to_modify == "type") { modified_listing.type = new_value; changed = true;}
        else if (field_to_modify == "price") { modified_listing.price = new_value; changed = true;}
        else if (field_to_modify == "size") { modified_listing.size = new_value; changed = true;}
        else if (field_to_modify == "rooms") { modified_listing.rooms = new_value; changed = true;}
        else if (field_to_modify == "bathrooms") { modified_listing.bathrooms = new_value; changed = true;}
        else if (field_to_modify == "parking") { modified_listing.parking = new_value; changed = true;}
        else {
            std::cout << YELLOW << "Invalid field specified." << RESET << std::endl;
            return;
        }
        
        
        if (changed) {
            
            
            std::stringstream ss;
            ss << modified_listing.orderNumber << ". "
               << modified_listing.type << ", "
               << modified_listing.price << ", "
               << modified_listing.size << ", "
               << modified_listing.rooms << ", "
               << modified_listing.bathrooms << ", "
               << modified_listing.parking;
            modified_listing.originalLine = ss.str(); 


            std::vector<Listing> all_listings = FileOps::readListingsFromFile(FileOps::LISTINGS_FILE);
            bool updated_in_vector = false;
            for (size_t i = 0; i < all_listings.size(); ++i) {
                if (all_listings[i].orderNumber == order_num) {
                    all_listings[i] = modified_listing; 
                    updated_in_vector = true;
                    break;
                }
            }

            if (updated_in_vector && FileOps::writeListingsToFile(FileOps::LISTINGS_FILE, all_listings)) {
                std::cout << GREEN << "Listing " << order_num << " modified successfully." << RESET << std::endl;
            } else if (!updated_in_vector) {
                std::cout << RED << "Critical error: Listing found but could not be updated in memory list." << RESET << std::endl;
            }
            else {
                std::cout << RED << "Failed to write modifications to file for listing " << order_num << "." << RESET << std::endl;
            }
        }
    }


    void viewPurchaseHistory() {
        FileOps::displayRawFileContents(FileOps::HISTORY_FILE, MAGENTA, "------- Purchase History -------");
    }

    void runAdminInteractiveMode() {
        int choice = -1;
        
        
        
        
        
        
        

        do {
            displayAdminHeader();
            std::cout << "Enter your choice: ";
            std::cin >> choice;

            if (std::cin.fail()) {
                std::cout << RED << "Invalid input. Please enter a number." << RESET << std::endl;
                FileOps::clearCinBuffer(); 
                choice = -1; 
                system("clear || cls"); 
                continue;
            }
            FileOps::clearCinBuffer(); 

            system("clear || cls"); 

            switch (choice) {
                case 1: viewListings(); break;
                case 2: addListing(); break;
                case 3: deleteListing(); break;
                case 4: modifyListing(); break;
                case 5: viewPurchaseHistory(); break;
                case 0: std::cout << YELLOW << "Exiting Admin Panel." << RESET << std::endl; break;
                default: std::cout << RED << "Invalid choice. Please try again." << RESET << std::endl; break;
            }
            if (choice != 0) {
                std::cout << "\nPress Enter to continue...";
                std::string dummy;
                std::getline(std::cin, dummy); 
                system("clear || cls");
            }

        } while (choice != 0);
    }

    void handleAdminCli(int argc, char *argv[]) {
        if (argc < 2) {
            std::cout << RED << "No command provided for admin app." << RESET << std::endl;
            runAdminInteractiveMode(); 
            return;
        }
        std::string command = argv[1];
        if (command == "view_listings") {
            viewListings();
        } else if (command == "add_listing" && argc == 8) { 
            int next_order_num = FileOps::getNextAvailableOrderNumber(FileOps::LISTINGS_FILE);
            std::stringstream new_listing_ss;
            new_listing_ss << next_order_num << ". "
                           << argv[2] << ", " << argv[3] << ", " << argv[4] << ", "
                           << argv[5] << ", " << argv[6] << ", " << argv[7];
            std::string new_listing_line = new_listing_ss.str() + "\n";
            if (FileOps::appendListingStringToFile(FileOps::LISTINGS_FILE, new_listing_line)) {
                std::cout << GREEN << "Listing added: " << new_listing_line << RESET;
            } else {
                std::cout << RED << "Failed to add listing via CLI." << RESET << std::endl;
            }
        } else if (command == "delete_listing" && argc == 3) { 
            try {
                int order_num = std::stoi(argv[2]);
                if (FileOps::removeListingByOrderNum(FileOps::LISTINGS_FILE, order_num)) {
                    std::cout << GREEN << "Listing " << order_num << " deleted." << RESET << std::endl;
                } else {
                    std::cout << YELLOW << "Failed to delete listing " << order_num << " (not found or error)." << RESET << std::endl;
                }
            } catch (const std::exception& e) {
                std::cout << RED << "Invalid order number for delete: " << argv[2] << RESET << std::endl;
            }
        } else if (command == "view_history") {
            viewPurchaseHistory();
        } else if (command == "modify_listing" && argc == 5) { 
            
            
            
            std::cout << YELLOW << "CLI modify_listing is basic: attempts to modify based on input." << RESET << std::endl;
             try {
                int order_num = std::stoi(argv[2]);
                std::string field = argv[3];
                std::string new_val = argv[4];

                std::vector<Listing> all_listings = FileOps::readListingsFromFile(FileOps::LISTINGS_FILE);
                bool found_and_updated = false;
                for (Listing& l : all_listings) {
                    if (l.orderNumber == order_num) {
                        if (field == "price") l.price = new_val;
                        else if (field == "type") l.type = new_val;
                        
                        else { std::cout << RED << "Unknown field: " << field << RESET << std::endl; return; }
                        
                        
                        std::stringstream ss;
                        ss << l.orderNumber << ". " << l.type << ", " << l.price << ", " << l.size << ", "
                           << l.rooms << ", " << l.bathrooms << ", " << l.parking;
                        l.originalLine = ss.str();
                        found_and_updated = true;
                        break;
                    }
                }
                if (found_and_updated && FileOps::writeListingsToFile(FileOps::LISTINGS_FILE, all_listings)) {
                    std::cout << GREEN << "Listing " << order_num << " field " << field << " updated." << RESET << std::endl;
                } else {
                    std::cout << RED << "Failed to modify listing " << order_num << " or field " << field << " not recognized/listing not found." << RESET << std::endl;
                }
            } catch (const std::exception& e) {
                std::cout << RED << "Error processing modify_listing command: " << e.what() << RESET << std::endl;
            }
        }
        else {
            std::cout << YELLOW << "Unknown admin command or incorrect arguments. Usage examples:" << RESET << std::endl;
            std::cout << BOLD << "./admin_app view_listings" << RESET << std::endl;
            std::cout << BOLD << "./admin_app add_listing \"Type\" \"Price\" \"Size\" \"Rooms\" \"Bathrooms\" \"Parking\"" << RESET << std::endl;
            std::cout << BOLD << "./admin_app delete_listing <order_number>" << RESET << std::endl;
            std::cout << BOLD << "./admin_app modify_listing <order_number> <field_name> \"<new_value>\"" << RESET << std::endl;
            std::cout << BOLD << "./admin_app view_history" << RESET << std::endl;
            std::cout << "Running interactive mode instead." << std::endl;
            runAdminInteractiveMode();
        }
    }
}