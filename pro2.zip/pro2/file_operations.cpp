#include "file_operations.h"
#include "ansi_colors.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm> 
#include <cstdio>    
#include <limits>    

namespace FileOps {

    void clearCinBuffer() {
        std::cin.clear(); 
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    std::vector<Listing> readListingsFromFile(const std::string& filename) {
        std::vector<Listing> listings_vector;
        std::ifstream file(filename);
        std::string line;

        if (!file.is_open()) {
            
            
            
            return listings_vector; 
        }

        while (std::getline(file, line)) {
            if (!line.empty()) {
                Listing current_listing(line); 
                if (current_listing.isValid()) {
                    listings_vector.push_back(current_listing);
                }
            }
        }
        file.close();
        return listings_vector;
    }

    bool writeListingsToFile(const std::string& filename, const std::vector<Listing>& listings_vector) {
        std::ofstream file(filename, std::ios::trunc); 
        if (!file.is_open()) {
            std::cerr << BOLD << RED << "Error: Could not open file " << filename << " for writing." << RESET << std::endl;
            return false;
        }
        for (const auto& listing_obj : listings_vector) {
            file << listing_obj.toString(); 
        }
        file.close();
        return true;
    }

    void displayParsedListings(const std::vector<Listing>& listings_vector, const std::string& header_color, const std::string& header_text) {
        if (!header_color.empty() && !header_text.empty()) {
            std::cout << BOLD << header_color << header_text << RESET << std::endl;
        }

        if (listings_vector.empty()) {
            std::cout << "No entries found." << std::endl;
        } else {
            for (const auto& listing_obj : listings_vector) {
                std::cout << listing_obj.toString(); 
            }
        }
        std::cout << CYAN << "------------------------------" << RESET << std::endl;
    }
    
    bool displayRawFileContents(const std::string& filename, const std::string& header_color, const std::string& header_text) {
        std::ifstream file(filename);
        std::string line;

        if (!header_color.empty() && !header_text.empty()) {
            std::cout << BOLD << header_color << header_text << RESET << std::endl;
        }

        if (!file.is_open()) {
            
            
            
            std::cout << "No entries found or file cannot be opened." << std::endl;
            std::cout << CYAN << "------------------------------" << RESET << std::endl;
            return false; 
        }

        int count = 0;
        while (std::getline(file, line)) {
            std::cout << line << std::endl;
            count++;
        }
        file.close();

        if (count == 0) {
            std::cout << "No entries found." << std::endl;
        }
        std::cout << CYAN << "------------------------------" << RESET << std::endl;
        return true;
    }


    bool appendListingStringToFile(const std::string& filename, const std::string& listing_string) {
        std::ofstream file(filename, std::ios::app); 
        if (!file.is_open()) {
            std::cerr << BOLD << RED << "Error: Could not open file " << filename << " for appending." << RESET << std::endl;
            return false;
        }
        file << listing_string; 
                                
        if (!listing_string.empty() && listing_string.back() != '\n') {
            file << '\n';
        }
        file.close();
        return !file.fail(); 
    }

    std::string findListingStringByOrderNum(const std::string& filename, int order_num) {
        std::ifstream file(filename);
        std::string line;
        if (!file.is_open()) {
            
            return ""; 
        }
        while (std::getline(file, line)) {
            if (Listing::extractOrderNumber(line) == order_num) {
                file.close();
                return line; 
            }
        }
        file.close();
        return ""; 
    }

    bool removeListingByOrderNum(const std::string& filename, int order_num_to_remove) {
        std::ifstream source_file(filename);
        if (!source_file.is_open()) {
            std::cerr << BOLD << RED << "Error: Could not open source file " << filename << " for removal." << RESET << std::endl;
            return false;
        }

        std::ofstream temp_file_stream(TEMP_FILE);
        if (!temp_file_stream.is_open()) {
            std::cerr << BOLD << RED << "Error: Could not create temporary file " << TEMP_FILE << "." << RESET << std::endl;
            source_file.close();
            return false;
        }

        std::string line;
        bool found = false;
        while (std::getline(source_file, line)) {
            if (Listing::extractOrderNumber(line) == order_num_to_remove) {
                found = true; 
            } else {
                temp_file_stream << line << '\n';
            }
        }
        source_file.close();
        temp_file_stream.close();

        if (!found) {
            
            
            std::remove(TEMP_FILE.c_str()); 
            return false; 
        }

        if (std::remove(filename.c_str()) != 0) {
            std::cerr << BOLD << RED << "Error: Could not delete original file " << filename << "." << RESET << std::endl;
            perror("Details");
            std::remove(TEMP_FILE.c_str()); 
            return false;
        }

        if (std::rename(TEMP_FILE.c_str(), filename.c_str()) != 0) {
            std::cerr << BOLD << RED << "Error: Could not rename temp file to " << filename << "." << RESET << std::endl;
            perror("Details");
            
            return false;
        }
        return true; 
    }

    int getNextAvailableOrderNumber(const std::string& filename) {
        std::vector<Listing> listings_vector = readListingsFromFile(filename);
        int max_order_num = 0;
        if (listings_vector.empty()) {
            return 1; 
        }
        for (const auto& listing_obj : listings_vector) {
            if (listing_obj.orderNumber > max_order_num) {
                max_order_num = listing_obj.orderNumber;
            }
        }
        return max_order_num + 1;
    }

    bool moveListing(const std::string& source_filename, const std::string& dest_filename, int order_num) {
        std::string listing_line_to_move = findListingStringByOrderNum(source_filename, order_num);

        if (listing_line_to_move.empty()) {
            std::cout << YELLOW << "Listing order number " << order_num << " not found in " << source_filename << "." << RESET << std::endl;
            return false; 
        }

        
        if (listing_line_to_move.back() != '\n') {
            listing_line_to_move += '\n';
        }

        if (!appendListingStringToFile(dest_filename, listing_line_to_move)) {
            std::cerr << BOLD << RED << "Failed to add listing to " << dest_filename << "." << RESET << std::endl;
            return false; 
        }

        if (!removeListingByOrderNum(source_filename, order_num)) {
            std::cerr << BOLD << RED << "Failed to remove listing from " << source_filename
                      << " after copying. Manual check might be needed." << RESET << std::endl;
            
            
            return false; 
        }
        return true; 
    }
}