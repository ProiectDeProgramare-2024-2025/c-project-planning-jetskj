#include "user_functions.h"
#include "file_operations.h"
#include "ansi_colors.h"
#include <iostream>
#include <string>
#include <vector>
#include <limits>    

namespace UserFunctions {

    void displayUserHeader() {
        std::cout << BOLD << CYAN << "------ USER MENU ------" << RESET << std::endl;
        std::cout << "1 - View Available Listings" << std::endl;
        std::cout << "2 - Add Listing to Favourites" << std::endl;
        std::cout << "3 - View Favourites" << std::endl;
        std::cout << "4 - Buy Listing" << std::endl;
        std::cout << "5 - View My Purchase History" << std::endl;
        std::cout << "0 - Exit User Panel" << std::endl;
        std::cout << CYAN << "-----------------------" << RESET << std::endl;
    }

    void viewAvailableListings() {
        std::cout << BOLD << GREEN << "------- Available Real Estate Listings -------" << RESET << std::endl;
        FileOps::displayRawFileContents(FileOps::LISTINGS_FILE, "", ""); 
    }

    void addListingToFavourites() {
        int order_num;
        viewAvailableListings(); 
        std::cout << "Enter order number of the listing to add to Favourites: ";
        std::cin >> order_num;
        if (std::cin.fail()) {
            std::cout << RED << "Invalid input. Please enter a number." << RESET << std::endl;
            FileOps::clearCinBuffer();
            return;
        }
        FileOps::clearCinBuffer(); 

        if (FileOps::moveListing(FileOps::LISTINGS_FILE, FileOps::FAVOURITES_FILE, order_num)) {
            std::cout << GREEN << "Listing " << order_num << " added to Favourites successfully." << RESET << std::endl;
        } else {
            std::cout << YELLOW << "Failed to add listing " << order_num << " to Favourites (may not exist or error)." << RESET << std::endl;
        }
    }

    void viewFavouritesList() {
        FileOps::displayRawFileContents(FileOps::FAVOURITES_FILE, YELLOW, "------- Your Favourite Listings -------");
    }

    void buyListing() {
        int order_num;
        
        
        
        std::cout << BOLD << "You can buy from available listings or your favourites." << RESET << std::endl;
        std::cout << "1. View Available Listings to Buy From" << std::endl;
        std::cout << "2. View Favourites to Buy From" << std::endl;
        std::cout << "Choose an option (or 0 to cancel): ";
        int choice;
        std::cin >> choice;
        if(std::cin.fail()){ FileOps::clearCinBuffer(); std::cout << RED << "Invalid choice." << RESET << std::endl; return;}
        FileOps::clearCinBuffer();

        std::string source_file_for_purchase;

        if (choice == 1) {
            viewAvailableListings();
            source_file_for_purchase = FileOps::LISTINGS_FILE;
        } else if (choice == 2) {
            viewFavouritesList();
            source_file_for_purchase = FileOps::FAVOURITES_FILE;
        } else {
            std::cout << "Purchase cancelled." << std::endl;
            return;
        }
        
        if(source_file_for_purchase.empty()){
             std::cout << "No valid source selected for purchase." << std::endl;
             return;
        }

        std::cout << "Enter order number of the listing to Buy from the displayed list: ";
        std::cin >> order_num;
        if (std::cin.fail()) {
            std::cout << RED << "Invalid input. Please enter a number." << RESET << std::endl;
            FileOps::clearCinBuffer();
            return;
        }
        FileOps::clearCinBuffer(); 

        if (FileOps::moveListing(source_file_for_purchase, FileOps::HISTORY_FILE, order_num)) {
            std::cout << GREEN << "Listing " << order_num << " purchased successfully and moved to history." << RESET << std::endl;
        } else {
            std::cout << YELLOW << "Failed to purchase listing " << order_num << " (may not exist in selected list or error)." << RESET << std::endl;
        }
    }

    void viewUserPurchaseHistory() {
        FileOps::displayRawFileContents(FileOps::HISTORY_FILE, MAGENTA, "------- Your Purchase History -------");
    }


    void runUserInteractiveMode() {
        int choice = -1;
        

        do {
            displayUserHeader();
            std::cout << "Enter your choice: ";
            std::cin >> choice;

            if (std::cin.fail()) {
                std::cout << RED << "Invalid input. Please enter a number." << RESET << std::endl;
                FileOps::clearCinBuffer();
                choice = -1; 
                system("clear || cls");
                continue;
            }
            FileOps::clearCinBuffer(); 

            system("clear || cls"); 

            switch (choice) {
                case 1: viewAvailableListings(); break;
                case 2: addListingToFavourites(); break;
                case 3: viewFavouritesList(); break;
                case 4: buyListing(); break;
                case 5: viewUserPurchaseHistory(); break;
                case 0: std::cout << YELLOW << "Exiting User Panel. Goodbye!" << RESET << std::endl; break;
                default: std::cout << RED << "Invalid choice. Please try again." << RESET << std::endl; break;
            }
            if (choice != 0) {
                std::cout << "\nPress Enter to continue...";
                std::string dummy;
                std::getline(std::cin, dummy); 
                system("clear || cls");
            }
        } while (choice != 0);
    }

    void handleUserCli(int argc, char *argv[]) {
        if (argc < 2) {
            std::cout << RED << "No command provided for user app." << RESET << std::endl;
            runUserInteractiveMode(); 
            return;
        }
        std::string command = argv[1];
        if (command == "view_listings") {
            viewAvailableListings();
        } else if (command == "add_favourite" && argc == 3) { 
            try {
                int order_num = std::stoi(argv[2]);
                if (FileOps::moveListing(FileOps::LISTINGS_FILE, FileOps::FAVOURITES_FILE, order_num)) {
                    std::cout << GREEN << "Listing " << order_num << " added to Favourites." << RESET << std::endl;
                } else {
                    std::cout << YELLOW << "Failed to add listing " << order_num << " to Favourites." << RESET << std::endl;
                }
            } catch (const std::exception& e) {
                std::cout << RED << "Invalid order number for add_favourite: " << argv[2] << RESET << std::endl;
            }
        } else if (command == "view_favourites") {
            viewFavouritesList();
        } else if (command == "buy_listing" && argc == 3) { 
            try {
                int order_num = std::stoi(argv[2]);
                 
                if (FileOps::moveListing(FileOps::LISTINGS_FILE, FileOps::HISTORY_FILE, order_num)) {
                    std::cout << GREEN << "Listing " << order_num << " purchased from available listings." << RESET << std::endl;
                } else {
                    std::cout << YELLOW << "Failed to buy listing " << order_num << " from available listings." << RESET << std::endl;
                }
            } catch (const std::exception& e) {
                std::cout << RED << "Invalid order number for buy_listing: " << argv[2] << RESET << std::endl;
            }
        } else if (command == "buy_favourite" && argc == 3) { 
             try {
                int order_num = std::stoi(argv[2]);
                if (FileOps::moveListing(FileOps::FAVOURITES_FILE, FileOps::HISTORY_FILE, order_num)) {
                    std::cout << GREEN << "Listing " << order_num << " purchased from favourites." << RESET << std::endl;
                } else {
                    std::cout << YELLOW << "Failed to buy listing " << order_num << " from favourites." << RESET << std::endl;
                }
            } catch (const std::exception& e) {
                std::cout << RED << "Invalid order number for buy_favourite: " << argv[2] << RESET << std::endl;
            }
        }
        else if (command == "view_history") {
            viewUserPurchaseHistory();
        } else {
            std::cout << YELLOW << "Unknown user command or incorrect arguments. Usage examples:" << RESET << std::endl;
            std::cout << BOLD << "./user_app view_listings" << RESET << std::endl;
            std::cout << BOLD << "./user_app add_favourite <order_number>" << RESET << std::endl;
            std::cout << BOLD << "./user_app view_favourites" << RESET << std::endl;
            std::cout << BOLD << "./user_app buy_listing <order_number_from_listings>" << RESET << std::endl;
            std::cout << BOLD << "./user_app buy_favourite <order_number_from_favourites>" << RESET << std::endl;
            std::cout << BOLD << "./user_app view_history" << RESET << std::endl;
            std::cout << "Running interactive mode instead." << std::endl;
            runUserInteractiveMode();
        }
    }
}