#include "listing.h"
#include <sstream>
#include <algorithm> 
#include <vector>    


std::string Listing::trim(const std::string& str) {
    const std::string whitespace = " \t\n\r\f\v";
    size_t first = str.find_first_not_of(whitespace);
    if (std::string::npos == first) {
        return ""; 
    }
    size_t last = str.find_last_not_of(whitespace);
    return str.substr(first, (last - first + 1));
}

Listing::Listing() : orderNumber(0), isValid_(false) {}

Listing::Listing(const std::string& line) : orderNumber(0), isValid_(false) {
    originalLine = trim(line); 
    if (originalLine.empty()) return;

    std::stringstream ss_line(originalLine);
    std::string order_part;

    
    if (!std::getline(ss_line, order_part, '.')) {
        return; 
    }

    try {
        orderNumber = std::stoi(trim(order_part));
    } catch (const std::invalid_argument& ia) {
        
        return;
    } catch (const std::out_of_range& oor) {
        
        return;
    }

    
    std::string details_part;
    if (!std::getline(ss_line, details_part)) { 
        return; 
    }
    details_part = trim(details_part); 

    std::vector<std::string> segments;
    std::stringstream detail_ss(details_part);
    std::string segment;

    
    while(std::getline(detail_ss, segment, ',')) {
        segments.push_back(trim(segment));
    }

    if (segments.size() >= 6) { 
        type = segments[0];
        price = segments[1];
        size = segments[2];
        rooms = segments[3];
        bathrooms = segments[4];
        parking = segments[5];
        isValid_ = true;
    } else {
        
        
        isValid_ = false;
    }
}

std::string Listing::toString() const {
    
    if (isValid_ && !originalLine.empty() && extractOrderNumber(originalLine) == orderNumber) {
        std::string temp_line = originalLine;
        
        if (temp_line.back() != '\n') {
            temp_line += "\n";
        }
        return temp_line;
    }
    
    if (!isValid_) return "\n"; 

    std::stringstream ss;
    ss << orderNumber << ". "
       << type << ", "
       << price << ", "
       << size << ", "
       << rooms << ", "
       << bathrooms << ", "
       << parking << "\n"; 
    return ss.str();
}

bool Listing::isValid() const {
    return isValid_;
}

int Listing::extractOrderNumber(const std::string& line) {
    std::string trimmed_line = trim(line);
    size_t dot_pos = trimmed_line.find('.');
    if (dot_pos != std::string::npos) {
        try {
            return std::stoi(trimmed_line.substr(0, dot_pos));
        } catch (const std::exception& e) {
            return 0; 
        }
    }
    return 0; 
}