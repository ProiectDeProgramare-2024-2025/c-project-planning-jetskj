#include "user_functions.h"
#include "file_operations.h" 
#include <iostream>

int main(int argc, char *argv[]) {
    

    if (argc > 1) {
        UserFunctions::handleUserCli(argc, argv);
    } else {
        
        UserFunctions::runUserInteractiveMode();
    }
    return 0;
}